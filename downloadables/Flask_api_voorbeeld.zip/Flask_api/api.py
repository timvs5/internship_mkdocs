import json
from flask import Flask, jsonify, request


app = Flask(__name__)
test_data = [ { 'id': 1, 'name': 'linear_regression' }, { 'id': 2, 'name': 'KNN' }, { 'id': 3, 'name': 'Naive Bayes' }]


@app.route('/getTestData', methods=['GET'])
def get_employees():
 return jsonify(test_data)


if __name__ == '__main__':
   app.run(port=5000)


