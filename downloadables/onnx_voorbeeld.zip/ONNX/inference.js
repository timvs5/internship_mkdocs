function inference(file_path) {
    const myOnnxSession = new onnx.InferenceSession();

    myOnnxSession.loadModel(file_path).then(function () {
        const inferenceInputs = new onnx.Tensor(new Float32Array([1]), 'float32', [1, 1]);

        myOnnxSession.run([inferenceInputs]).then(function (output) {
            const outputTensor = output.values().next().value;
            console.log('Model output tensor:', outputTensor.data);
            console.log('Model output tensor value:', outputTensor.data[0]);
        });
    }).catch(function (error) {
        console.error('Error loading the ONNX model:', error);
    });
}