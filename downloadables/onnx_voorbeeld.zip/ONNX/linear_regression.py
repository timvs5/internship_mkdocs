
from sklearn.linear_model import LinearRegression
import numpy as np
import torch
import torch.nn as nn



class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.linear = nn.Linear(1, 1)

    def forward(self, x):
        return self.linear(x)
    

def build_and_train_linear_regression_model():
    np.random.seed(42)
    X_train = 2 * np.random.rand(100, 1)
    y_train = 4 + 3 * X_train + np.random.randn(100, 1)

    model = LinearRegression()

    model.fit(X_train, y_train)

    return model