import linear_regression as lr
import onnx
import torch
import torch.onnx
import torch.nn


def make_onnx_model():
    filename = input("Name the ONNX file: ")
    onnx_file_path = "models/" + filename + ".onnx"
    input_name = "In"

    model = lr.SimpleModel()
    dummy_input = torch.randn(1, 1)

    torch.onnx.export(model, dummy_input, onnx_file_path, input_names=[input_name])


make_onnx_model()
