function linear_regression() {
    const SimpleLinearRegression = ML.SimpleLinearRegression;

    const x = [0.5, 1, 1.5, 2, 2.5];
    const y = [0, 1, 2, 3, 4];

    const regression = new SimpleLinearRegression(x, y);
    console.log("Linear regression made")  
    console.log("slope: " + regression.slope)  // 2

    console.log("Predicting for 4: " + regression.predict(4)) // 5

    console.log("regression: " + regression.toString()) // 'f(x) = 2 * x - 1'
}