async function execute_from_python_file() {
    let pyodide = await loadPyodide()
    await pyodide.loadPackage("micropip")
    const micropip = pyodide.pyimport("micropip")

    await micropip.install("scikit-learn")

    const pythonScriptResponse = await fetch('linear_regression.py')
    const pythonScript = await pythonScriptResponse.text()

    pyodide.runPython(pythonScript)
}