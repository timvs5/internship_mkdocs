from sklearn.linear_model import LinearRegression
import numpy as np


np.random.seed(42) 
X_train = 2 * np.random.rand(100, 1)
y_train = 4 + 3 * X_train + np.random.randn(100, 1)

model = LinearRegression()

model.fit(X_train, y_train)

X_new = np.array([[0], [2]])
y_pred = model.predict(X_new)

print(f"Slope (Coefficient): {model.coef_[0][0]}")
print(f"Intercept: {model.intercept_[0]}")

print("Predictions for new data:")
for i in range(len(X_new)):
    print(f"Input: {X_new[i][0]}, Predicted Output: {y_pred[i][0]}")